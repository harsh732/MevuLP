<?php
    $dbhost = '127.0.0.1:3306';
   $dbuser = 'root';
   $dbpass = '123456';
   $dbname = 'mevu';
    $email=$_POST['email'];
    $pwd=$_POST['password'];
//   $dbhost = '172.18.5.31:3306';
//   $dbuser = 'u1004317_sa481';
//   $dbpass = '(3~bI]0SZi5}v0sq';
//   $dbname = 'db1004317_sa481_main';
    echo $email;
    echo $pwd;
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
   if(! $conn )
   {
     die('Could not connect: ' . mysql_error());
   }
   echo 'Connected successfully';
    $sql = "INSERT INTO mevu.users (email,password)
VALUES ('$email','$pwd')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
   mysqli_close($conn);
header('Location: index.html');
?>